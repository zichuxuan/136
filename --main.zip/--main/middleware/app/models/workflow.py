from sqlalchemy import Column, Integer, String, JSON, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from middleware.app.core.database import Base

class Workflow(Base):
    """
    工作流表 (Workflow)
    """
    __tablename__ = "workflows"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, index=True, nullable=False, comment="工作流名称")
    status = Column(String(50), nullable=True, comment="工作流状态")
    
    details = Column(JSON, nullable=False, comment="工作流详情 json: 画布上的详细信息")
    type = Column(String(50), nullable=False, comment="工作流类型")
    input_params = Column(JSON, nullable=True, comment="工作流入参参数 json")

    logs = relationship("WorkflowExecutionLog", back_populates="workflow", cascade="all, delete-orphan")


class WorkflowExecutionLog(Base):
    """
    工作流执行日志表 (WorkflowExecutionLog)
    """
    __tablename__ = "workflow_execution_logs"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False, comment="工作流id")
    status = Column(String(50), nullable=False, comment="工作流执行状态")
    error_message = Column(Text, nullable=True, comment="错误信息")
    executed_at = Column(DateTime(timezone=True), server_default=func.now(), comment="执行时间")
    execution_logs = Column(JSON, nullable=True, comment="执行日志")

    workflow = relationship("Workflow", back_populates="logs")
