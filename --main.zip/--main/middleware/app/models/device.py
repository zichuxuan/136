from sqlalchemy import Column, Integer, String, JSON, ForeignKey, Boolean, Float, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from middleware.app.core.database import Base

class DeviceModel(Base):
    """
    设备型号表 (DeviceModel)
    """
    __tablename__ = "device_models"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, index=True, nullable=False, comment="设备型号")
    protocol = Column(String(50), nullable=False, comment="设备通讯协议")

    devices = relationship("Device", back_populates="device_model")


class Device(Base):
    """
    设备实例表 (Device)
    """
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    device_code = Column(String(100), unique=True, index=True, nullable=False, comment="设备编号")
    name = Column(String(255), index=True, nullable=False, comment="设备名称")
    device_model_id = Column(Integer, ForeignKey("device_models.id"), nullable=False, comment="设备型号id")
    device_category = Column(String(100), nullable=True, comment="设备类别")
    production_line = Column(String(100), nullable=True, comment="所属产线")
    location = Column(String(255), nullable=True, comment="所在位置")
    status = Column(String(50), nullable=True, comment="设备状态")
    
    device_data = Column(JSON, nullable=True, comment="设备数据 json: 运行时长, 最大容量...")
    is_inverter = Column(Boolean, default=False, comment="是否变频")
    frequency = Column(Float, nullable=True, comment="频率")
    
    connection_config = Column(JSON, nullable=False, comment="通讯参数 json: ip, 端口, 寄存器地址")

    device_model = relationship("DeviceModel", back_populates="devices")
    actions = relationship("DeviceAction", back_populates="device", cascade="all, delete-orphan")
    logs = relationship("DeviceLog", back_populates="device", cascade="all, delete-orphan")


class DeviceAction(Base):
    """
    设备动作表 (DeviceAction)
    """
    __tablename__ = "device_actions"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, comment="设备实例id")
    name = Column(String(255), nullable=False, comment="动作名称")
    command_params = Column(JSON, nullable=False, comment="动作指令参数 json")

    device = relationship("Device", back_populates="actions")


class DeviceLog(Base):
    """
    设备日志表 (DeviceLog)
    """
    __tablename__ = "device_logs"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, comment="设备实例id")
    level = Column(String(50), nullable=False, comment="日志级别")
    event_type = Column(String(50), nullable=False, comment="事件类型")
    message = Column(String(255), nullable=False, comment="日志简短摘要")
    details = Column(JSON, nullable=True, comment="详细信息 json")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), comment="日志产生时间")

    device = relationship("Device", back_populates="logs")
