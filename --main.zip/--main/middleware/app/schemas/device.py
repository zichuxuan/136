from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

# --- DeviceAction Schemas ---

class DeviceActionBase(BaseModel):
    name: str = Field(..., description="动作名称")
    command_params: Dict[str, Any] = Field(..., description="动作指令参数 json")

class DeviceActionCreate(DeviceActionBase):
    device_id: int = Field(..., description="设备实例id")

class DeviceActionUpdate(BaseModel):
    name: Optional[str] = Field(None, description="动作名称")
    command_params: Optional[Dict[str, Any]] = Field(None, description="动作指令参数 json")

class DeviceAction(DeviceActionBase):
    id: int = Field(..., description="设备动作ID")
    device_id: int = Field(..., description="设备实例id")

    model_config = ConfigDict(from_attributes=True)


# --- DeviceLog Schemas ---

class DeviceLogBase(BaseModel):
    level: str = Field(..., description="日志级别")
    event_type: str = Field(..., description="事件类型")
    message: str = Field(..., description="日志简短摘要")
    details: Optional[Dict[str, Any]] = Field(None, description="详细信息 json")

class DeviceLogCreate(DeviceLogBase):
    device_id: int = Field(..., description="设备实例id")

class DeviceLog(DeviceLogBase):
    id: int = Field(..., description="日志ID")
    device_id: int = Field(..., description="设备实例id")
    created_at: Optional[datetime] = Field(None, description="日志产生时间")

    model_config = ConfigDict(from_attributes=True)


# --- DeviceModel Schemas ---

class DeviceModelBase(BaseModel):
    name: str = Field(..., description="设备型号")
    protocol: str = Field(..., description="设备通讯协议")

class DeviceModelCreate(DeviceModelBase):
    pass

class DeviceModelUpdate(BaseModel):
    name: Optional[str] = Field(None, description="设备型号")
    protocol: Optional[str] = Field(None, description="设备通讯协议")

class DeviceModel(DeviceModelBase):
    id: int = Field(..., description="设备型号ID")

    model_config = ConfigDict(from_attributes=True)


# --- Device Schemas ---

class DeviceBase(BaseModel):
    device_code: str = Field(..., description="设备编号")
    name: str = Field(..., description="设备名称")
    device_category: Optional[str] = Field(None, description="设备类别")
    production_line: Optional[str] = Field(None, description="所属产线")
    location: Optional[str] = Field(None, description="所在位置")
    status: Optional[str] = Field(None, description="设备状态")
    device_data: Optional[Dict[str, Any]] = Field(None, description="设备数据 json")
    is_inverter: bool = Field(False, description="是否变频")
    frequency: Optional[float] = Field(None, description="频率")
    connection_config: Dict[str, Any] = Field(..., description="通讯参数 json")

class DeviceCreate(DeviceBase):
    device_model_id: int = Field(..., description="设备型号id")

class DeviceUpdate(BaseModel):
    device_code: Optional[str] = Field(None, description="设备编号")
    name: Optional[str] = Field(None, description="设备名称")
    device_model_id: Optional[int] = Field(None, description="设备型号id")
    device_category: Optional[str] = Field(None, description="设备类别")
    production_line: Optional[str] = Field(None, description="所属产线")
    location: Optional[str] = Field(None, description="所在位置")
    status: Optional[str] = Field(None, description="设备状态")
    device_data: Optional[Dict[str, Any]] = Field(None, description="设备数据 json")
    is_inverter: Optional[bool] = Field(None, description="是否变频")
    frequency: Optional[float] = Field(None, description="频率")
    connection_config: Optional[Dict[str, Any]] = Field(None, description="通讯参数 json")

class Device(DeviceBase):
    id: int = Field(..., description="设备实例ID")
    device_model_id: int = Field(..., description="设备型号id")
    actions: List[DeviceAction] = Field(default=[], description="动作列表")
    logs: List[DeviceLog] = Field(default=[], description="设备日志列表")

    model_config = ConfigDict(from_attributes=True)
