from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

# --- WorkflowExecutionLog Schemas ---

class WorkflowExecutionLogBase(BaseModel):
    status: str = Field(..., description="工作流执行状态")
    error_message: Optional[str] = Field(None, description="错误信息")
    execution_logs: Optional[Dict[str, Any]] = Field(None, description="执行日志 json")

class WorkflowExecutionLogCreate(WorkflowExecutionLogBase):
    workflow_id: int = Field(..., description="工作流id")

class WorkflowExecutionLogUpdate(BaseModel):
    status: Optional[str] = Field(None, description="工作流执行状态")
    error_message: Optional[str] = Field(None, description="错误信息")
    execution_logs: Optional[Dict[str, Any]] = Field(None, description="执行日志 json")

class WorkflowExecutionLog(WorkflowExecutionLogBase):
    id: int = Field(..., description="执行日志ID")
    workflow_id: int = Field(..., description="工作流id")
    executed_at: Optional[datetime] = Field(None, description="执行时间")

    model_config = ConfigDict(from_attributes=True)


# --- Workflow Schemas ---

class WorkflowBase(BaseModel):
    name: str = Field(..., description="工作流名称")
    status: Optional[str] = Field(None, description="工作流状态")
    details: Dict[str, Any] = Field(..., description="工作流详情 json")
    type: str = Field(..., description="工作流类型")
    input_params: Optional[Dict[str, Any]] = Field(None, description="工作流入参参数 json")

class WorkflowCreate(WorkflowBase):
    pass

class WorkflowUpdate(BaseModel):
    name: Optional[str] = Field(None, description="工作流名称")
    status: Optional[str] = Field(None, description="工作流状态")
    details: Optional[Dict[str, Any]] = Field(None, description="工作流详情 json")
    type: Optional[str] = Field(None, description="工作流类型")
    input_params: Optional[Dict[str, Any]] = Field(None, description="工作流入参参数 json")

class Workflow(WorkflowBase):
    id: int = Field(..., description="工作流ID")
    logs: List[WorkflowExecutionLog] = Field(default=[], description="执行日志列表")

    model_config = ConfigDict(from_attributes=True)
