-- ==========================================================
-- 自动生成的 MySQL DDL 脚本
-- 来源模型：
--   1. middleware/app/models/device.py
--   2. middleware/app/models/workflow.py
-- ==========================================================

-- --------------------------------------------------------
-- 表结构 `device_models` (设备型号表)
-- --------------------------------------------------------
CREATE TABLE `device_models` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，设备型号的唯一标识符',
    `name` VARCHAR(255) NOT NULL COMMENT '设备型号',
    `protocol` VARCHAR(50) NOT NULL COMMENT '设备通讯协议',
    PRIMARY KEY (`id`),
    UNIQUE INDEX `ix_device_models_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备型号表';

-- --------------------------------------------------------
-- 表结构 `devices` (设备实例表)
-- --------------------------------------------------------
CREATE TABLE `devices` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，设备实例的唯一标识符',
    `device_code` VARCHAR(100) NOT NULL COMMENT '设备编号',
    `name` VARCHAR(255) NOT NULL COMMENT '设备名称',
    `device_model_id` INT NOT NULL COMMENT '设备型号id',
    `device_category` VARCHAR(100) DEFAULT NULL COMMENT '设备类别',
    `production_line` VARCHAR(100) DEFAULT NULL COMMENT '所属产线',
    `location` VARCHAR(255) DEFAULT NULL COMMENT '所在位置',
    `status` VARCHAR(50) DEFAULT NULL COMMENT '设备状态',
    `device_data` JSON DEFAULT NULL COMMENT '设备数据 json: 运行时长, 最大容量...',
    `is_inverter` BOOLEAN DEFAULT FALSE COMMENT '是否变频',
    `frequency` FLOAT DEFAULT NULL COMMENT '频率',
    `connection_config` JSON NOT NULL COMMENT '通讯参数 json: ip, 端口, 寄存器地址',
    PRIMARY KEY (`id`),
    UNIQUE INDEX `ix_devices_device_code` (`device_code`),
    INDEX `ix_devices_name` (`name`),
    CONSTRAINT `fk_devices_device_model_id` FOREIGN KEY (`device_model_id`) REFERENCES `device_models` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备实例表';

-- --------------------------------------------------------
-- 表结构 `device_actions` (设备动作表)
-- --------------------------------------------------------
CREATE TABLE `device_actions` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，设备动作的唯一标识符',
    `device_id` INT NOT NULL COMMENT '设备实例id',
    `name` VARCHAR(255) NOT NULL COMMENT '动作名称',
    `command_params` JSON NOT NULL COMMENT '动作指令参数 json',
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_device_actions_device_id` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备动作表';

-- --------------------------------------------------------
-- 表结构 `device_logs` (设备日志表)
-- --------------------------------------------------------
CREATE TABLE `device_logs` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，日志唯一标识符',
    `device_id` INT NOT NULL COMMENT '外键，关联的设备实例 ID',
    `level` VARCHAR(50) NOT NULL COMMENT '日志级别 (如: INFO, WARN, ERROR, DEBUG)',
    `event_type` VARCHAR(50) NOT NULL COMMENT '事件类型 (如: COMMAND, STATUS_CHANGE, TELEMETRY, ALARM)',
    `message` VARCHAR(255) NOT NULL COMMENT '日志简短摘要/描述',
    `details` JSON DEFAULT NULL COMMENT '详细信息 (如: 完整的指令报文、错误堆栈、遥测快照等)',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '日志产生时间',
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_device_logs_device_id` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备日志表';


-- --------------------------------------------------------
-- 表结构 `workflows` (工作流表)
-- --------------------------------------------------------
CREATE TABLE `workflows` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，工作流的唯一标识符',
    `name` VARCHAR(255) NOT NULL COMMENT '工作流名称',
    `status` VARCHAR(50) DEFAULT NULL COMMENT '工作流状态',
    `details` JSON NOT NULL COMMENT '工作流详情 json: 画布上的详细信息',
    `type` VARCHAR(50) NOT NULL COMMENT '工作流类型',
    `input_params` JSON DEFAULT NULL COMMENT '工作流入参参数 json',
    PRIMARY KEY (`id`),
    UNIQUE INDEX `ix_workflows_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流表';

-- --------------------------------------------------------
-- 表结构 `workflow_execution_logs` (工作流执行日志表)
-- --------------------------------------------------------
CREATE TABLE `workflow_execution_logs` (
    `id` INT NOT NULL AUTO_INCREMENT COMMENT '主键，执行日志的唯一标识符',
    `workflow_id` INT NOT NULL COMMENT '工作流id',
    `status` VARCHAR(50) NOT NULL COMMENT '工作流执行状态',
    `error_message` TEXT DEFAULT NULL COMMENT '错误信息',
    `execution_logs` JSON DEFAULT NULL COMMENT '执行日志',
    `executed_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '执行时间',
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_workflow_execution_logs_workflow_id` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流执行日志表';
