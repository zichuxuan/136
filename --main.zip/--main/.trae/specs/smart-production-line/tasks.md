# Tasks

- [x] Task 1: Create SQLAlchemy Database Models
  - [x] SubTask 1.1: Create `DeviceModel` model in `middleware/app/models/device.py`
  - [x] SubTask 1.2: Create `DeviceAction` model in `middleware/app/models/device.py`
  - [x] SubTask 1.3: Create `Device` model in `middleware/app/models/device.py`
  - [x] SubTask 1.4: Create `Workflow` model in `middleware/app/models/workflow.py`
  - [x] SubTask 1.5: Create `WorkflowExecutionLog` model in `middleware/app/models/workflow.py`
- [x] Task 2: Create Pydantic Schemas for Database Models
  - [x] SubTask 2.1: Create schemas for `DeviceModel`, `DeviceAction`, and `Device` in `middleware/app/schemas/device.py`
  - [x] SubTask 2.2: Create schemas for `Workflow` and `WorkflowExecutionLog` in `middleware/app/schemas/workflow.py`

# Task Dependencies
- [Task 2] depends on [Task 1]