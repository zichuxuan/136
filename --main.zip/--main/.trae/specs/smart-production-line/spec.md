# 智能产线网关与终端数据库架构 Spec

## Why
在基于 ARM 架构（如 3588 开发板）的边缘计算场景中，需要开发一套智能产线系统（终端使用 PyQt6，网关负责协议与数据），实现低代码拖拽式设备控制流编排。不同设备有异构的通讯协议（Modbus TCP, RS485, RS232 等）和指令。通过合理的数据库设计，将设备资产、通讯参数、动作指令库与工作流拓扑结构解耦，能极大提升系统的可扩展性和稳定性。

## What Changes
- 设计并创建 `device_models` 表：用于存储支持的设备型号及对应协议。
- 设计并创建 `device_actions` 表：用于存储特定设备型号的动作指令库（如下发何种 Modbus 报文）。
- 设计并创建 `devices` 表：用于存储用户实际添加的物理设备实例，利用 JSON 字段存储异构的通讯参数。
- 设计并创建 `workflows` 表：用于存储用户在前端画布编排的工作流（利用 JSON 字段存储 Topology）。
- 设计并创建 `workflow_execution_logs` 表：用于记录工作流执行的历史状态与报错日志。

## Impact
- Affected specs: 边缘网关数据存储与设备抽象能力、终端低代码工作流引擎的数据交互契约。
- Affected code: `middleware/app/models/`（SQLAlchemy 模型定义），`middleware/app/schemas/`（Pydantic 数据验证）。

## ADDED Requirements
### Requirement: 设备型号与动作指令抽象
The system SHALL provide a dictionary for device models and their supported actions.

#### Scenario: Success case
- **WHEN** user selects a "Siemens S7-1200" device model on the UI.
- **THEN** the system fetches all supported `device_actions` (e.g., "Start Spindle", "Read Temp") for this model, along with their low-level payload templates.

### Requirement: 异构设备通讯配置
The system SHALL store dynamic connection configurations for different physical devices using JSON format.

#### Scenario: Success case
- **WHEN** user adds a new Modbus TCP device and an RS485 device.
- **THEN** the system stores `{"ip": "192.168.1.10", "port": 502}` and `{"port": "/dev/ttyS1", "baudrate": 9600}` respectively in the `connection_config` JSON column of the `devices` table without altering the table schema.

### Requirement: 低代码工作流拓扑存储
The system SHALL persist the drag-and-drop workflow topology as JSON and track its running state.

#### Scenario: Success case
- **WHEN** user links a condition node after a device action node and saves the workflow.
- **THEN** the system saves the entire node/edge mapping into the `topology` JSON column of the `workflows` table and supports setting `trigger_type` to active or passive.