# PyQt6 桌面应用开发规范（AI 编程工具专用）

> 适用范围：
>
> * PyQt6
> * Windows 桌面应用
> * 架构：MVVM（Qt Signals）
> * 目标：可维护、可扩展、产品级代码

---

## 一、总体架构规范（强制）

### 1.1 架构模式

**必须使用 MVVM（Qt 风格）**：

```
View (QWidget / QMainWindow)
  ↓ signals / slots
ViewModel (QObject)
  ↓ 调用
Service (纯 Python)
  ↓ 调用
Infrastructure (HTTP / DB / IO)
```

### 1.2 分层依赖规则（硬性约束）

| 层级        | 允许依赖                    | 明确禁止                    |
| --------- | ----------------------- | ----------------------- |
| View      | ViewModel               | ❌ Service / ❌ IO / ❌ 线程 |
| ViewModel | Service / Domain        | ❌ QWidget / ❌ 直接 IO     |
| Qt Model  | Domain                  | ❌ Service / ❌ ViewModel |
| Service   | Infrastructure / Domain | ❌ Qt / ❌ UI             |
| Domain    | 无                       | ❌ Qt / ❌ requests       |

**任何违反分层的代码都视为错误实现。**

---

## 二、View（UI）层规范

### 2.1 职责

View 只能做：

* UI 布局
* 控件样式（QSS）
* 用户事件绑定（clicked / changed）
* 绑定 ViewModel signals 更新界面

### 2.2 明确禁止

View 中 **禁止**：

* 直接调用 Service
* 网络 / 文件 IO
* 线程 / sleep / requests
* 业务判断（if status == ...）

### 2.3 UI 代码示例（合规）

```python
self.refresh_btn.clicked.connect(self.vm.load_devices)
self.vm.devicesChanged.connect(self.table_model.setDevices)
```

---

## 三、ViewModel 规范（核心）

### 3.1 基本要求

* 必须继承 `QObject`
* 必须使用 `pyqtSignal` 通知 View
* 所有 UI 状态必须通过 signal 暴露

### 3.2 ViewModel 职责

* 维护页面状态（busy / data / error）
* 调用 Service
* 协调线程池

### 3.3 标准 ViewModel 结构

```python
class XxxViewModel(BaseViewModel):
    dataChanged = pyqtSignal(object)

    def load(self):
        self.set_busy(True)
        worker = ThreadPool.instance().submit(self._service.load)
        worker.signals.result.connect(self._on_loaded)

    def _on_loaded(self, data):
        self.dataChanged.emit(data)
        self.set_busy(False)
```

### 3.4 登录/注册 ViewModel 示例

```python
class LoginViewModel(BaseViewModel):
    loginSuccess = pyqtSignal(User)
    loginFailed = pyqtSignal(str)
    registerSuccess = pyqtSignal()
    registerFailed = pyqtSignal(str)

    def login(self, username, password):
        # 参数校验
        # 设置忙碌状态
        # 提交到线程池执行

    def register(self, username, password, confirm_password):
        # 参数校验
        # 设置忙碌状态
        # 提交到线程池执行
```

### 3.5 明确禁止

* ❌ 在 ViewModel 中操作 QWidget
* ❌ 在 ViewModel 中直接访问 QTableView
* ❌ 在 ViewModel 中做耗时 IO（必须走 ThreadPool）

---

## 四、Qt Model（QAbstractTableModel）规范

### 4.1 使用场景

* 所有表格 / 列表数据
* 禁止使用 QListWidget / QTreeWidget 作为最终方案

### 4.2 设计原则

* Model 只负责 **数据 → 单元格映射**
* 数据来源只能来自 ViewModel

### 4.3 必须实现的方法

```python
rowCount()
columnCount()
data()
headerData()
```

### 4.4 更新数据的唯一方式

```python
beginResetModel()
self._items = items
endResetModel()
```

---

## 五、Service 层规范

### 5.1 职责

* 纯业务逻辑
* 数据整理 / 校验
* 调用 API / DB
* 密码加密与验证（认证服务）

### 5.2 约束

* ❌ 不得 import PyQt6
* ❌ 不得 emit signal
* ❌ 不得感知 UI 存在

### 5.3 密码加密示例

```python
def _hash_password(self, password: str) -> str:
    """
    密码加密
    """
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def _verify_password(self, password: str, hashed_password: str) -> bool:
    """
    密码验证
    """
    return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
```

---

## 六、线程与并发规范（非常重要）

### 6.1 统一线程模型

* 所有耗时操作 **必须** 使用 `ThreadPool`
* UI 线程只负责渲染

### 6.2 合法示例

```python
worker = ThreadPool.instance().submit(self._service.fetch)
worker.signals.result.connect(self._on_loaded)
```

### 6.3 禁止行为

* ❌ UI 线程中 requests.get()
* ❌ time.sleep()
* ❌ 自建 QThread（统一使用 ThreadPool）

---

## 七、Signals 使用规范

### 7.1 命名规范

* 状态变化：`xxxChanged`
* 错误：`errorOccurred`
* 加载状态：`busyChanged`

### 7.2 Signals 是唯一通信方式

* View ← ViewModel：signals
* View → ViewModel：方法调用

---

## 八、异常与错误处理

* 所有异常在 ViewModel 捕获
* ViewModel 只 emit 错误文本
* View 决定如何展示（MessageBox / Toast）

```python
except Exception as e:
    self.errorOccurred.emit(str(e))
```

---

## 九、命名与代码风格

* 文件名：`snake_case.py`
* 类名：`PascalCase`
* ViewModel：`XxxViewModel`
* Qt Model：`XxxTableModel`

---

## 十、AI 编程工具行为约束（强制遵守）

当新增功能时，AI 必须按以下步骤：

1. 新建 Domain Model（如需要）
2. 新建 Service
3. 新建 ViewModel（定义 signals）
4. 修改或新增 Qt Model
5. 最后修改 View 进行绑定

**禁止一步跨层实现功能。**

---

## 十一、合规性自检清单（AI 必须自检）

* [ ] View 是否直接访问 Service？（必须否）
* [ ] 是否在 UI 线程执行 IO？（必须否）
* [ ] 是否所有 UI 更新来自 signal？（必须是）
* [ ] 是否使用 QAbstractTableModel？（必须是）
* [ ] 是否保持单向依赖？（必须是）

---

> 结论：
> **只要严格遵守本规范，代码即可直接进入生产级 PyQt6 桌面应用。**
